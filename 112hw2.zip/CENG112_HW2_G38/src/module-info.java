/**
 * 
 */
/**
 * @author sudetoral
 *
 */
module ZCarRent {
}