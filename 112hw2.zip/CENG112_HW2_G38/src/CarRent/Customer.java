package CarRent;
import java.util.Random;

public class Customer {
	Random rand = new Random();
	private double threshold;
	private String ID;

	public Customer(int iD) {
		double randthreshold = 1 + 2*rand.nextDouble();
		this.threshold = randthreshold;
		ID = "customer" + iD;
	}
	
	public double getThreshold() {
		return threshold;
	}

	public void setThreshold(double threshold) {
		this.threshold = threshold;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	@Override
	public String toString() {
		return "Customer [ID=" + ID + "]";
	}
	

	}
