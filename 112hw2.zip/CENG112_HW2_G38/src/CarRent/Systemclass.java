package CarRent;
import java.util.Random;
import java.util.Scanner;
import java.text.DecimalFormat;
public class Systemclass {
	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	int Day = 1;

	
	public IList<Car> createCarList(){
		System.out.println("Enter that how many cars");
		int N = scan.nextInt();
		IList<Car> carList = new List<>(N);
		int carnumber = 0;
		for (int i = 0; i < N ; i++) {
			Car car = new Car(carnumber);
			carList.add(car);
			carnumber++;}
		return carList;
	}
	
	public IDeque<Car> createDequeFromList(IList<Car> carlist){
		IDeque<Car> carDeque = new Deque<>(carlist.getlenght());
		Object[] carArray = carlist.toArray();
		for (Object obj : carArray) {
		    Car car = (Car)obj;
		    carDeque.addToBack(car);}
		return carDeque;
	}
	
	
	public IQueue<Customer> createCustomerQueue() {
		System.out.println("Enter that how many customers");
		int k = scan.nextInt();
		IQueue<Customer> customerqueue = new Queue<>(k);
		int customernumber = 0;
		for (int i = 0; i < k ; i++) {
			Customer customer = new Customer(customernumber);
			customerqueue.enqueue(customer);
			customernumber++;}
		return customerqueue;
		}
	
	public IQueue<Customer> cretatenewcustomerqueue(Customer currentcus,IQueue<Customer> oldcustomerqueue){
		IQueue<Customer> tempqueue = new Queue<>(oldcustomerqueue.getNumberEntry());
		Object[] oldarray = oldcustomerqueue.toArray();
		for (Object obj : oldarray) {
			Customer customer = (Customer) obj;
			if (customer == null) {
				continue;}
            tempqueue.enqueue(customer);}
		return tempqueue;}
	
	
	public void eachRentDay(Car car) {
		car.setCurrentrent(Car.getPossibleRent()[rand.nextInt(Car.getPossibleRent().length)]);
	}
	
	public void rentSystem() {
		IList<Car> carlist = createCarList();
		IDeque<Car> carDeque = (Deque<Car>) createDequeFromList(carlist);
		IQueue<Customer> customerqueue = (Queue<Customer>) createCustomerQueue();
		while (!customerqueue.isEmpty()) {
			System.out.println("***************** Day " + Day + " ******************");
			int carnumberforday = carDeque.getNumberOfEntries();
			Customer deletedcustomer = null;
			for (int i = 0; i < carnumberforday ; i++) {
				if (customerqueue.isEmpty()) {
					break;
				}
				Car currentcar = carDeque.removeFront();
				DecimalFormat df1 = new DecimalFormat(" . 00");
				System.out.println("Current " + currentcar.getID() + " guailty : " + df1.format(currentcar.getGualityscore()) + " is offering to ");
				double currentgualityscore = currentcar.getGualityscore();
				for (int x = 0; x < customerqueue.getNumberEntry() ; x++) {
					Customer currentcustomer = customerqueue.dequeue();
					DecimalFormat df = new DecimalFormat(" . 00");
					System.out.print("            " + "Current" + currentcustomer.getID() + " threshold : " + df.format(currentcustomer.getThreshold()));
				if (currentcustomer.getThreshold() < currentgualityscore) {
						System.out.println("                  -- accepted");
						eachRentDay(currentcar);
						currentcar.setRentedby(currentcustomer.getID());
						deletedcustomer = currentcustomer;
						customerqueue = cretatenewcustomerqueue(deletedcustomer, customerqueue);
						break;
						
						}
					else {
						System.out.println("                  -- not accepted");
						currentcustomer.setThreshold(currentcustomer.getThreshold()*0.9);
						customerqueue.enqueue(currentcustomer);
						
			}
					
					}
				
					if (!currentcar.isRentednow()) {
						carDeque.addToBack(currentcar);
					
				}
				}
			if (customerqueue.isEmpty()) {
				break;}
			
			System.out.println("All cars have seen");
			System.out.println("But there are still customers waiting");
			
			System.out.println("Rented cars :");
			Object[] carArray = carlist.toArray();
			for (Object obj : carArray) {
				Car carx = (Car)obj;
				carx.setTempoccupancy(carx.getCurrentrent());
				if (carx.isRentednow()) {
					System.out.println("             " + carx.getID() + " by " + carx.getRentedby() + " occupancy : " + carx.getCurrentrent());
					carx.setCurrentrent(carx.getCurrentrent() - 1);
					if (carx.getCurrentrent() == 0) {
						carDeque.addToFront(carx);}}
			}
			System.out.println("Avaiable cars");
			for (Object obj : carArray) {
				Car carx = (Car)obj;
				if (carx.getTempoccupancy() == 0) {
					System.out.println("             " + carx.getID());
				}
			}

			System.out.println("***************** End Of The Day ******************");
			Day++;}
		
		System.out.println("All customers rent a car");
	}
}

		
	

		
		
	


