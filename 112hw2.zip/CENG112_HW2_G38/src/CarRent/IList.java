package CarRent;

public interface IList<T> {
	public void add(T entry);
	public void add(int newPositoion,T newEntry);
	public T remove(int givenPosition);
	public T replace(int givenposition,T newEntry);
	public T[] toArray();
	public int getlenght();
	public void ensurecapacity();
	
	

}
