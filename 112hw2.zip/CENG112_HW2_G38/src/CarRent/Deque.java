package CarRent;

public class Deque<T> implements IDeque<T> {
	T[] deque;
	int frontindex;
	int backindex;
	int numberofentry = 0;
	
	
	
	@SuppressWarnings("unchecked")
	public Deque(int length) {
		T[] temp = (T[]) new Object[length];
		frontindex = 0;
		backindex = length - 1;
		deque = temp;
	}

	@Override
	public void addToFront(T newEntry) {
		 if (isFull()) {
	            throw new RuntimeException("Deque is full");
	        }
		 	if (frontindex == 0) {
	            frontindex = deque.length - 1;
	        } else {
	            frontindex--;
	        }

	        deque[frontindex] = newEntry;
	        numberofentry++;
	    }


	@Override
	public void addToBack(T newEntry) {
	     if (isFull()) {
	            throw new RuntimeException("Deque is full");
	        }
	     	if (backindex == deque.length - 1) {
	            backindex = 0;
	        } else {
	            backindex++;
	        }

	        deque[backindex] = newEntry;
	        numberofentry++;}

	@Override
	public T removeFront() {
	      if (isEmpty()) {
	            throw new RuntimeException("Deque is empty");
	        }

	        T value = deque[frontindex];
	        deque[frontindex] = null;
	        if (frontindex == deque.length - 1) {
	            frontindex = 0;
	        } else {
	            frontindex++;
	        }

	        numberofentry--;
	        return value;
	}
	

	@Override
	public T removeBack() {
	      if (isEmpty()) {
	            throw new RuntimeException("Deque is empty");
	        }

	        T value = deque[backindex];
	        deque[backindex] = null;
	        if (backindex == 0) {
	            backindex = deque.length - 1;
	        } else {
	            backindex--;
	        }

	        numberofentry--;
	        return value;
	
	}

	@Override
	public T getFront() {
		return deque[frontindex];
	}

	@Override
	public T getBack() {
		return deque[backindex];
		
	}
	
	@Override
	public boolean isFull() {
		return numberofentry == deque.length;
		
	}
	
	@Override
	public boolean isEmpty() {
		return numberofentry == 0;
	}
	
	@Override
	public int getNumberOfEntries() {
		return numberofentry;
	}
	
	public int getLength() {
		return deque.length;
	}
	




	

}
