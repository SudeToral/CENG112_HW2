package CarRent;

public class Queue<T> implements IQueue<T>{
	T[] queue;
	private int frontindex;
	private int backindex;
	int numberentry = 0;
 

	@SuppressWarnings("unchecked")
	public Queue(int lenght) {
		T[] temp = (T[]) new  Object[lenght];
		queue = temp;
		frontindex = 0;
		backindex = lenght - 1;
}

	@Override
	public void enqueue(T entry) {
		 if (isFull()) {
	            ensurecapacity();}
		 backindex = (backindex + 1) % queue.length;
		 queue[backindex] = entry;
		 numberentry++;
	}

	@Override
	public T dequeue() {
		 if (isEmpty()) {
	            throw new RuntimeException("queue is empty");}
		T front = queue[frontindex];
		queue[frontindex] = null;
		frontindex = (frontindex + 1) % queue.length;
		numberentry--;
		return front;
		
	}
	@SuppressWarnings("unchecked")
	@Override
	public T[] toArray() {
		T[] result = (T[]) new Object[queue.length];
		for (int index = 0 ; index < queue.length; index++) {
			result[index] = queue[index];}
			return result;

		}
	public void wiew() {
		for (int index = 0 ;index < queue.length ; index++) {
			if (queue[index] == null) {
				System.out.println("null");
			}
			else {
			System.out.println(queue[index].toString());}
		}}
	

	@Override
	public int getNumberEntry() {
		return numberentry;
	}

	@Override
	public T getFront() {
		return queue[frontindex];
	}

	@SuppressWarnings("unchecked")
	@Override
	public void ensurecapacity() {
		if (isFull()) {
			T[] oldqueue = queue;
			int oldsize = oldqueue.length;
			int newsize = 2*oldsize;
			T[] temp = (T[]) new Object[newsize];
			queue = temp;
			for (int i = 0 ; i < oldsize -1 ; i++) {
				queue[i] = oldqueue[frontindex];
				frontindex = (frontindex + 1) % oldsize;}
			frontindex = 0;
			backindex = oldsize - 2;}
			}

	@Override
	public boolean isFull() {
		return numberentry == queue.length;
	
		
	}
	public boolean isEmpty() {
		return numberentry == 0;
	}

	@Override
	public int getLength() {
		return queue.length;
	}

	
	

}
