package CarRent;

public interface IDeque<T> {
	public void addToFront(T newEntry);
	public void addToBack(T newEnrty);
	public T removeFront();
	public T removeBack();
	public T getFront();
	public T getBack();
	public boolean isEmpty();
	public boolean isFull();
	public int getNumberOfEntries();
	public int getLength();
	
	

}
