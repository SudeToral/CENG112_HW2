package CarRent;

public interface IQueue<T> {
	public void enqueue(T entry);
	public T dequeue();
	public T[] toArray();
	public int getNumberEntry();
	public T getFront();
	public void ensurecapacity();
	public boolean isFull();
	public boolean isEmpty();
	public int getLength();
	public void wiew();


}
