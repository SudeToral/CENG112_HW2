package CarRent;

import java.util.Arrays;

public class List<T> implements IList<T> {
	T[] list;
	int numberofentries = 0;
	
	
	@SuppressWarnings("unchecked")
	public List(int length) {
	T[] temp = (T[]) new Object[length + 1];
	list = temp;
	}
	
	
	
	@Override
	public void add(T entry) {
		list[numberofentries + 1] = entry;
		numberofentries++;
		
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public T[] toArray() {
		T[] result = (T[]) new Object[numberofentries];
		for (int index = 0 ;index < numberofentries; index++) {
			result[index] = list[index + 1];}
			return result;
		
	}
	@Override
	public void ensurecapacity() {
		int capacity= list.length - 1;
		if (numberofentries >= capacity){
			int newcapacity = capacity*2;
			list = Arrays.copyOf(list, newcapacity + 1);
		}

}
	@Override
	public int getlenght() {
		return numberofentries;
	}
	
	
	@Override
	public void add(int newPositoion, T newEntry) {
		// TODO Auto-generated method stub
		}
	
	@Override
	public T remove(int givenPosition) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public T replace(int givenposition, T newEntry) {
		// TODO Auto-generated method stub
		return null;
	}
		
	
	
	
	
	
	
	

}
