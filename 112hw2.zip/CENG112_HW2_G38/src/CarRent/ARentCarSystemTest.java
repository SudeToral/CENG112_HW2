package CarRent;

public class ARentCarSystemTest {

	public static void main(String[] args) {
		Systemclass rentalcarsystem = new Systemclass();
		rentalcarsystem.rentSystem();

	}

}
