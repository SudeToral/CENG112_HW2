package CarRent;

import java.util.Random;

public class Car {
	Random rand = new Random();
	private String ID;
	private static final int[] possibleRent = {1,2,3,4,5};
	private int currentRent;
	private double gualityscore;
	private String rentedby;
	private int tempoccupancy;

	public static int[] getPossibleRent() {
		return possibleRent;
	}
	//delete
	@Override
	public String toString() {
		return "Car [ID=" + ID + "]";
	}
	
	public Car(int iD) {
		double randguality = 1 + 2*rand.nextDouble();
		this.gualityscore = randguality;
		ID = "car" + iD;
		}
	
	
	public boolean isRentednow() {
		return currentRent > 0;
	}
	

	public String getRentedby() {
		return rentedby;
	}

	public void setRentedby(String rentedby) {
		this.rentedby = rentedby;
	}

	public double getGualityscore() {
		return gualityscore;
	}

	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public int getCurrentrent() {
		return currentRent;
	}
	public void setCurrentrent(int currentrent) {
		this.currentRent = currentrent;
	}

	public int getTempoccupancy() {
		return tempoccupancy;
	}
	public void setTempoccupancy(int tempoccupancy) {
		this.tempoccupancy = tempoccupancy;
	}
	


	


	
}
